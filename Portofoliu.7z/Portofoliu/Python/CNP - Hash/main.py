import random
import names
import datetime
import time


def generare_CNP(sx, an, j):
    ms9 = [1, 7]
    fs9 = [2, 8]
    ms8 = [3, 7]
    fs8 = [4, 8]
    ms20 = [5, 7]
    fs20 = [6, 8]
    if sx == "m":
        if 1900 <= an <= 1999:
            s = random.choice(ms9)
        elif 1800 <= an <= 1899:
            s = random.choice(ms8)
        elif 2000 <= an <= 2099:
            s = random.choice(ms20)
    else:
        if 1900 <= an <= 1999:
            s = random.choice(fs9)
        elif 1800 <= an <= 1899:
            s = random.choice(fs8)
        elif 2000 <= an <= 2099:
            s = random.choice(fs20)
    a1 = an // 10 % 10
    a2 = an % 10
    l1 = random.randint(0, 1)
    if l1 == 1:
        l2 = random.randint(0, 2)
    else:
        l2 = random.randint(1, 9)
    if (l1 == 0 and l2 != 2) or (l1 == 1 and l2 in [0, 1, 2]):
        z1 = random.randint(0, 3)
        if z1 == 3 and (l1 == 0 and l2 in [1, 3, 5, 7, 8]) or (l1 == 1 and l2 in [0, 2]):
            z2 = random.randint(0, 1)
        elif z1 == 3 and (l1 == 0 and l2 in [4, 6, 9]) or (l1 == 1 and l2 == 1):
            z2 = 0
        elif z1 == 0:
            z2 = random.randint(1, 9)
        else:
            z2 = random.randint(0, 9)
    else:
        z1 = random.randint(0, 2)
        if z1 == 2 and an % 4 != 0:
            z2 = random.randint(0, 8)
        elif z1 == 0:
            z2 = random.randint(1, 9)
        else:
            z2 = random.randint(0, 9)
    if j < 10:
        j1 = 0
        j2 = j
    else:
        j1 = j // 10 % 10
        j2 = j % 10
    n1 = random.randint(0, 9)
    n2 = random.randint(0, 9)
    n3 = random.randint(0, 9)
    tc = (s * 2 + a1 * 7 + a2 * 9 + l1 + l2 * 4 + z1 * 6 + z2 * 3 + j1 * 5 + j2 * 8 + n1 * 2 + n2 * 7 + n3 * 9) % 11
    if tc == 10:
        c = 1
    else:
        c = tc
    cnp = str(s) + str(a1) + str(a2) + str(l1) + str(l2) + str(z1) + str(z2) + str(j1) + str(j2) + str(n1) + str(
        n2) + str(n3) + str(c)
    return cnp


def generare_nume(sx):
    if sx == "m":
        nume = names.get_full_name(gender='male')
    else:
        nume = names.get_full_name(gender='female')
    return nume


def generator_date(l):
    x = datetime.datetime.now()
    for i in range(1000000):
        sd = random.randint(1, 100)
        vd = random.randint(1, 100)
        jd = random.randint(1, 100)
        if 1 <= sd <= 49:
            sx = "m"
        else:
            sx = "f"
        if 1 <= vd <= 16:
            an = random.randint(0, 14)
        elif 17 <= vd <= 76:
            an = random.randint(15, 59)
        else:
            an = random.randint(60, 100)
        if 1 <= jd <= 10:
            j = 40
        elif 11 <= jd <= 14:
            j = 22
        elif 15 <= jd <= 18:
            j = 29
        elif 19 <= jd <= 21:
            j = 12
        elif 22 <= jd <= 24:
            j = 13
        elif 25 <= jd <= 27:
            j = 35
        elif 28 <= jd <= 30:
            j = 16
        elif 31 <= jd <= 33:
            j = 33
        elif 34 <= jd <= 36:
            j = 4
        elif 37 <= jd <= 39:
            j = 3
        elif 40 <= jd <= 42:
            j = 5
        elif 43 <= jd <= 45:
            j = 26
        elif 46 <= jd <= 48:
            j = 17
        elif 49 <= jd <= 51:
            j = 8
        elif 52 <= jd <= 53:
            j = 15
        elif 54 <= jd <= 56:
            j = 27
        elif 57 <= jd <= 59:
            j = 24
        elif 60 <= jd <= 61:
            j = 10
        elif 62 <= jd <= 63:
            j = 28
        elif 64 <= jd <= 65:
            j = 2
        elif 66 <= jd <= 67:
            j = 20
        elif 68 <= jd <= 69:
            j = 7
        elif 70 <= jd <= 71:
            j = 37
        elif 72 <= jd <= 73:
            j = 32
        elif 74 <= jd <= 75:
            j = 38
        elif 76 <= jd <= 77:
            j = 34
        elif 78 <= jd <= 79:
            j = 23
        elif 78 <= jd <= 79:
            j = 23
        elif 78 <= jd <= 79:
            j = 23
        elif 78 <= jd <= 79:
            j = 23
        elif 78 <= jd <= 79:
            j = 23
        elif 78 <= jd <= 79:
            j = 23
        elif 80 <= jd <= 81:
            j = 18
        elif 82 <= jd <= 83:
            j = 1
        elif 84 <= jd <= 85:
            j = 39
        elif 86 <= jd <= 87:
            j = 30
        elif 88 <= jd <= 89:
            j = 9
        elif 90 <= jd <= 91:
            j = 19
        elif jd == 92:
            j = 6
        elif jd == 93:
            j = 11
        elif jd == 94:
            j = 41
        elif jd == 95:
            j = 42
        elif jd == 96:
            j = 21
        elif jd == 97:
            j = 25
        elif jd == 98:
            j = 31
        elif jd == 99:
            j = 36
        else:
            j = 14
        l.append({"nume": generare_nume(sx), "CNP": generare_CNP(sx, int(x.year) - an, j)})


def hash_CNP(cnp):
    h = 1
    while cnp != 0:
        u = cnp % 10
        if u == 0:
            u = 1
        h = h * u
        cnp = cnp // 10
    if h >= 1000:
        h = h % 1000
    return h


if __name__ == '__main__':
    y = datetime.datetime.now()
    tdate = []
    lcnpd = []
    nrj = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    nrm = 0
    nrf = 0
    nrt = 0
    nra = 0
    nrb = 0
    mic = 0
    start = time.perf_counter()
    generator_date(tdate)
    for j in tdate:
        lcnpd.append(j['CNP'])
    hcnp = [[] for _ in range(1000)]
    for t in lcnpd:
        hcnp[hash_CNP(int(t))].append(t)
    for cp in range(1000):
        c = 0
        cnpc = random.choice(lcnpd)
        c1 = int(cnpc) // 1000000000000
        c2 = int(cnpc) // 100000000000 % 10
        c3 = int(cnpc) // 10000000000 % 10
        c4 = int(cnpc) // 100000 % 10
        c5 = int(cnpc) // 10000 % 10
        for m in hcnp[hash_CNP(int(cnpc))]:
            if m == cnpc:
                print(f"Numar de iteratii necesare pentru cautarea CNP-ului ales: {c}")
                print(f"CNP-ul cautat: {cnpc}")
                mic = mic + c
                break
            c = c + 1
        if c1 in [1, 3, 5, 7]:
            nrm = nrm + 1
        else:
            nrf = nrf + 1
        if c1 in [1, 2] or (c1 in [5, 6, 7, 8] and (2000 + c2 * 10 + c3 > y.year)):
            an1 = int(y.year) - (1000 + 900 + c2 * 10 + c3)
        elif c1 in [3, 4]:
            an1 = int(y.year) - (1000 + 800 + c2 * 10 + c3)
            if an1 > 100:
                an1 = an1 - 100
        elif c1 in [5, 6, 7, 8] and (2000 + c2 * 10 + c3 <= y.year):
            an1 = int(y.year) - (2000 + c2 * 10 + c3)
        if 0 <= an1 <= 14:
            nrt = nrt + 1
        elif 15 <= an1 <= 59:
            nra = nra + 1
        else:
            nrb = nrb + 1
        if c4 == 0:
            cj = c5
        else:
            cj = int(str(c4) + str(c5))
        for p in range(42):
            if cj - 1 == p:
                nrj[cj - 1] = nrj[cj - 1] + 1
    end = time.perf_counter()
    print(f"Timp de executie pentru generare si cautare: {end - start}")
    print("Repartitia CNP-urilor pe judete")
    for p in range(42):
        if p < 41:
            print(nrj[p], end=" ")
        else:
            print(nrj[p])
    print(f"Procent CNP-uri care apartin persoanelor masculine: {nrm / 1000 * 100}")
    print(f"Procent CNP-uri care apartin persoanelor feminine: {nrf / 1000 * 100}")
    print(f"Procent CNP-uri care apartin persoanelor tinere: {nrt / 1000 * 100}")
    print(f"Procent CNP-uri care apartin persoanelor adulte: {nra / 1000 * 100}")
    print(f"Procent CNP-uri care apartin persoanelor batrane: {nrb / 1000 * 100}")
    print("Repartitia CNP-urilor pe judete, sub forma de procentaj")
    for p in range(42):
        if p < 41:
            print(nrj[p] / 1000 * 100, end=" ")
        else:
            print(nrj[p] / 1000 * 100)
    print(f"Numarul mediu de iteratii necesare pentru gasirea tuturor CNP-urilor alese: {mic // 1000}")