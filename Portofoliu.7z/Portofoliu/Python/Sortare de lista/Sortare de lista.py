import time


def bubble_sort(un_list):
    st = time.time()
    n = len(un_list)
    sort = False
    while not sort:
        sort = True
        for i in range(n - 1):
            if un_list[i] > un_list[i + 1]:
                un_list[i], un_list[i + 1] = un_list[i + 1], un_list[i]
                sort = False
    et = time.time()
    tt = et - st
    print(tt)


def bubble_sort_optimized(un_list):
    st = time.time()
    n = len(un_list)
    sort = False
    j = 1
    while not sort:
        sort = True
        for i in range(n - j):
            if un_list[i] > un_list[i + 1]:
                un_list[i], un_list[i + 1] = un_list[i + 1], un_list[i]
                sort = False
        j = j + 1
    et = time.time()
    tt = et - st
    print(tt)


def insert_sort(un_list):
    st = time.time()
    n = len(un_list)
    for i in range(1, n):
        elem_cur = un_list[i]
        poz_cur = i
        while poz_cur > 0 and un_list[poz_cur - 1] >= elem_cur:
            un_list[poz_cur] = un_list[poz_cur - 1]
            poz_cur = poz_cur - 1
        un_list[poz_cur] = elem_cur
    et = time.time()
    tt = et - st
    print(tt)


def interchange_sort(un_list):
    st = time.time()
    n = len(un_list)
    for i in range(n - 1):
        for j in range(i + 1, n):
            if un_list[i] > un_list[j]:
                un_list[i], un_list[j] = un_list[j], un_list[i]
    et = time.time()
    tt = et - st
    print(tt)


def select_sort(un_list):
    st = time.time()
    n = len(un_list)
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            if un_list[j] < un_list[min_index]:
                min_index = j
        un_list[i], un_list[min_index] = un_list[min_index], un_list[i]
    et = time.time()
    tt = et - st
    print(tt)


def quick_sort(un_list, poz_init, poz_fin):
    if poz_init < poz_fin:
        pivot = poz_init
        i = poz_init + 1
        j = poz_fin
        while i < j:
            while un_list[i] < un_list[pivot] and i < poz_fin:
                i = i + 1
            while un_list[j] > un_list[pivot]:
                j = j - 1
            if i < j:
                un_list[i], un_list[j] = un_list[j], un_list[i]
        un_list[pivot], un_list[j] = un_list[j], un_list[pivot]
        quick_sort(un_list, poz_init, j - 1)
        quick_sort(un_list, j + 1, poz_fin)


def merge_sort(un_list):
    if len(un_list) > 1:
        poz_mij = len(un_list) // 2
        un_listS = un_list[:poz_mij]
        un_listR = un_list[poz_mij:]
        merge_sort(un_listS)
        merge_sort(un_listR)
        i = j = k = 0
        while i < len(un_listS) and j < len(un_listR):
            if un_listS[i] < un_listR[j]:
                un_list[k] = un_listS[i]
                i += 1
            else:
                un_list[k] = un_listR[j]
                j += 1
            k += 1
        while i < len(un_listS):
            un_list[k] = un_listS[i]
            i += 1
            k += 1
        while j < len(un_listR):
            un_list[k] = un_listR[j]
            j += 1
            k += 1


if __name__ == '__main__':
    lt1 = [7, 53, 27, 790, 42, 9, 0, 532, 2, 55432, 7542, 11, 864, 32, 5, 86, 3231, 664, 34, 23, 0]
    lt2 = [7, 53, 27, 790, 42, 9, 0, 532, 2, 55432, 7542, 11, 864, 32, 5, 86, 3231, 664, 34, 23, 0]
    lt3 = [7, 53, 27, 790, 42, 9, 0, 532, 2, 55432, 7542, 11, 864, 32, 5, 86, 3231, 664, 34, 23, 0]
    lt4 = [7, 53, 27, 790, 42, 9, 0, 532, 2, 55432, 7542, 11, 864, 32, 5, 86, 3231, 664, 34, 23, 0]
    lt5 = [7, 53, 27, 790, 42, 9, 0, 532, 2, 55432, 7542, 11, 864, 32, 5, 86, 3231, 664, 34, 23, 0]
    lt6 = [7, 53, 27, 790, 42, 9, 0, 532, 2, 55432, 7542, 11, 864, 32, 5, 86, 3231, 664, 34, 23, 0]
    bubble_sort(lt1)
    bubble_sort_optimized(lt2)
    insert_sort(lt3)
    interchange_sort(lt4)
    select_sort(lt5)
    st = time.time()
    merge_sort(lt6)
    et = time.time()
    tt = et - st
    print(tt)
    print(lt1)
    print(lt2)
    print(lt3)
    print(lt4)
    print(lt5)
    print(lt6)