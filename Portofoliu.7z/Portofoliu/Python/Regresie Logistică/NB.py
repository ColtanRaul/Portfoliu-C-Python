from sklearn import preprocessing
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn import metrics
import pandas as pd
import numpy as np

weather = ['Sunny', 'Sunny', 'Overcast', 'Rainy', 'Rainy', 'Rainy', 'Overcast', 'Sunny', 'Sunny',
           'Rainy', 'Sunny', 'Overcast', 'Overcast', 'Rainy', 'Overcast']
temp = ['Hot', 'Hot', 'Hot', 'Mild', 'Cool', 'Cool', 'Cool', 'Mild', 'Cool', 'Mild', 'Mild', 'Mild', 'Hot', 'Mild', 'Cool']

play = ['No', 'No', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'No']

le = preprocessing.LabelEncoder()

weather_encoded = le.fit_transform(weather)
print("Weather:", weather_encoded)

temp_encoded = le.fit_transform(temp)
label = le.fit_transform(play)

print("Temperature:", temp_encoded)
print("Play:", label)
# Weather: Sunny - 2, Overcast - 0, Rainy - 1
# Temperature: Hot - 1, Mild - 2, Cool - 0
# Play: No - 0, Yes - 1
cases = {'Weather': weather_encoded,
         'Temperature': temp_encoded,
         'Play?': label}

df = pd.DataFrame(cases, columns=['Weather', 'Temperature', 'Play?'])
X = df[['Weather', 'Temperature']]
Y = df[['Play?']]

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.33, random_state=0)

model = GaussianNB()
model.fit(X_train, np.ravel(Y_train))
Y_pred = model.predict(X_test)

print(X_test)
print(Y_test)
print(Y_pred)

print('Accuracy: ', metrics.accuracy_score(Y_test, Y_pred))

w1 = ['Overcast', 'Rainy', 'Sunny']
t1 = ['Mild', 'Hot', 'Cool']

w1_encoded = le.fit_transform(w1)
print("Weather:", w1_encoded)

t1_encoded = le.fit_transform(t1)
print("Temperature:", t1_encoded)

pcases = {'Weather': w1_encoded,
          'Temperature': t1_encoded}

ndf = pd.DataFrame(pcases, columns=['Weather', 'Temperature'])

predictions = model.predict(ndf)
print(ndf)
print(predictions)
