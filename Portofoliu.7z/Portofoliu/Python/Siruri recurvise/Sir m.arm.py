def marm(a, b, n):
    if n == 0:
        return a
    elif n == 1:
        return b
    else:
        return 2 * marm(a, b, n - 1) * marm(a, b, n - 2) / (marm(a, b, n - 1) + marm(a, b, n - 2))


a = float(input('a='))
b = float(input('b='))
n = int(input('n='))
print('Termenul de ordinul ', n,' este ',format(marm(a,b,n), '.5f'))
