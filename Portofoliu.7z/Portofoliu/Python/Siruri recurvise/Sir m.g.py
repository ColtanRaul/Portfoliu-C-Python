from math import sqrt


def mg(a, b, n):
    if n == 0:
        return a
    elif n == 1:
        return b
    else:
        return sqrt(mg(a, b, n - 1) * mg(a, b, n - 2))


a = float(input('a='))
b = float(input('b='))
n = int(input('n='))
print('Termenul de ordinul ', n, ' este ', format(mg(a, b, n), '.5f'))
