def ma(a, b, n):
    if n == 0:
        return a
    elif n == 1:
        return b
    else:
        return (ma(a, b, n - 1) + ma(a, b, n - 2)) / 2


a = float(input('a='))
b = float(input('b='))
n = int(input('n='))
print('Termenul de ordinul ', n, ' este ', format(ma(a, b, n), '.5f'))
