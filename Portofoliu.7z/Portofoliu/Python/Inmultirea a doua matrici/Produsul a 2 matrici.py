from numpy import zeros, dot

m = int(input('m='))
n = int(input('n='))
p = int(input('p='))
a = zeros((m, n), dtype=float)
b = zeros((n, p), dtype=float)
c = zeros((m, p), dtype=float)
print('Dati matricea a, pe linii')
for i in range(0, m):
    for j in range(0, n):
        print('a[', i, j, ']=')
        a[i, j] = eval(input())
print('Dati matricea b, pe linii')
for i in range(0, n):
    for j in range(0, p):
        print('b[', i, j, ']=')
        b[i, j] = eval(input())
print('a=')
print(a)
print('b=')
print(b)
for i in range(0, m):
    for j in range(0, p):
        for k in range(0, m):
            c[i, j] = c[i, j] + a[i, k] * b[k, j]
print('Matricea produs este:')
print(c)
print('Verificare cu functia dot')
print('dot(a,b)=')
print(dot(a, b))
