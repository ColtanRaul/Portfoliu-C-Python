#include <iostream>
#include <fstream>
#define INF 99999
using namespace std;
ifstream f("matrice_valori.txt");
int n, V[50][50], S[50], j, lambda[50];
void CitireV()
{
    int i, k;
    f>>n;
    for(i=1; i<=n; i++)
        for(k=1; k<=n; k++)
        {
            f>>V[i][k];
            if(V[i][k] == -1)
                V[i][k] = INF;
        }

}
void AfisareV()
{
    int i, k;
    for(i=1; i<=n; i++)
    {
        for(k=1; k<=n; k++)
        {
            if(V[i][k] == INF)
                cout<<"INF"<<" ";
            else
                cout<<V[i][k]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}
void Init()
{
    int i;
    S[1] = 0;
    for(i=2; i<=n; i++)
        S[i] = 1;
    for(i=1; i<=n; i++)
        lambda[i]=V[1][i];
}
void AfisareS()
{
    int i;
    cout<<"S: ";
    for(i=1; i<=n; i++)
        cout<<S[i]<<" ";
    cout<<endl;
}
void AfisareLambda()
{
    int i;
    cout<<"Lambda: ";
    for(i=1; i<=n; i++)
        if(lambda[i] == INF)
            cout<<"INF ";
        else
            cout<<lambda[i]<<" ";
    cout<<endl;
}
int Snevid()
{
    int i = 1;
    while(S[i] == 0 && i<=n)
    {
        i++;
    }
    if(i<=n)
        return 1;
    return 0;
}
int Lmin()
{
    int i, lm = INF, poz = 0;
    for(i=1; i<=n; i++)
        if(lm>lambda[i] && S[i] == 1)
        {
            lm = lambda[i];
            poz = i;
        }
    return poz;
}
void ModificareL()
{
    int i;
    for(i=1; i<=n; i++)
    {
        if(V[j][i] < INF && S[i] == 1)
        {
            if(lambda[j] + V[j][i] < lambda[i])
                lambda[i] = lambda[j] + V[j][i];
        }
    }

}
void Dijk()
{
    Init();
    while(Snevid())
    {
        AfisareS();
        AfisareLambda();
        j=Lmin();
        cout<<"j="<<j<<endl;
        S[j]=0;
        if(Snevid())
            ModificareL();
    }
    AfisareLambda();
}

int main()
{
    CitireV();
    AfisareV();
    Dijk();

    return 0;
}
