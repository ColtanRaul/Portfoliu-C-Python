#include <iostream>


using namespace std;
#include <cmath>
int prim(int x)
{int d,OK;
if(x>=2) OK=1;
else OK=0;
d=2;
while(d<=sqrt(x)&&OK==1)
    if(x%d==0) OK=0;
    else d++;

return OK;



}

int main()
{int n;
cin>>n;
prim(n);

    return 0;
}
