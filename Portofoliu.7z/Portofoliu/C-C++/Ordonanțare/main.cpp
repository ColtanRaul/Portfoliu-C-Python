#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    cout<<3;
    return 0;
}
