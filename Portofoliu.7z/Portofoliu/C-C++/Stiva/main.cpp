#include <iostream>
#include <string.h>
using namespace std;

struct Nod
{
    string cod_produs, nume_produs;
    float pret_unitar, cantitate, valoare_totala;
    Nod *urmator;
};


struct Stiva
{
    Nod* varf;
    float total;
};

Nod* citire()
{
    Nod *citit = new Nod;
    cout<<"Codul produsului: ";
    cin>>citit -> cod_produs;
    cout<<"Numele produsului: ";
    cin>>citit -> nume_produs;
    cout<<"Pretul produsului: ";
    cin>>citit -> pret_unitar;
    cout<<"Cantitatea produsului: ";
    cin>>citit -> cantitate;
    citit -> valoare_totala = citit -> pret_unitar * citit -> cantitate;
    citit -> urmator = NULL;
    return citit;
}

void init(Stiva &stiva)
{
    cout<<"initializare\n";
    stiva.varf = NULL;
    stiva.total = 0;
}

void afisare_produs(Nod* produs)
{
    cout<<"\n===============\nDin produsul cu codul "<<produs->cod_produs<<" si numele "<<produs->nume_produs<<endl;
    cout<<"sunt "<< produs->cantitate<<" bucati, la pretul "<<produs->pret_unitar<<" cu o valoare "<<produs->valoare_totala<<".\n===============\n";
}

void afis(Stiva stiva)
{
    Nod *actual = stiva.varf;
    while (actual != NULL)
    {
        afisare_produs(actual);
        actual = actual -> urmator;
    }
    cout<<"\nProdusele din magazin au o valoare totala de: "<<stiva.total<<" lei."<<endl;
}

void adauga(Stiva &stiva)
{
    Nod *de_adaugat;
    cout<<"adauga\n";
    de_adaugat = citire();
    de_adaugat -> urmator = stiva.varf;
    stiva.varf = de_adaugat;
    stiva.total = stiva.total + de_adaugat -> valoare_totala;
}

void extragere(Stiva &stiva)
{
    Nod *de_sters = new Nod;
    if(stiva.varf)
    {
        cout<<"sterge\n";
        de_sters = stiva.varf;
        stiva.varf = de_sters -> urmator;
        stiva.total = stiva.total - de_sters -> valoare_totala;
        delete de_sters;
    }
    else
        cout<<"Stiva este goala!";
}

void cautare(Stiva stiva, float x)
{   Nod *actual = stiva.varf;
    while (actual != NULL && actual -> cantitate != x)
    {
        actual = actual -> urmator;
    }
    if (actual == NULL)
        cout<<"NU";
    else cout<<"DA";
}

int main()
{   float cant;
    cout<<"Cantitatea cautata este: ";
    cin>>cant;
    Stiva magazin_1;
    init(magazin_1);
    adauga(magazin_1);
    adauga(magazin_1);
    adauga(magazin_1);
    adauga(magazin_1);
    afis(magazin_1);
    //extragere(magazin_1);
    //afis(magazin_1);
    //cautare(magazin_1, cant);
    return 0;
}
