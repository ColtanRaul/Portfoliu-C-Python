#include <iostream>

using namespace std;

struct Nod
{
    int pr, pim;
    Nod *prec,*urm;
};

struct Coada
{
    Nod *prim, *ultim;

};

Nod* citire()
{
    Nod *citit = new Nod;
    cout<<"Partea reala: ";
    cin>>citit -> pr;
    cout<<"Partea imaginara: ";
    cin>>citit -> pim;
    citit -> urm = citit->prec = NULL;
    return citit;
}

void init(Coada &coada)
{
    cout<<"initializare\n";
    coada.prim = NULL;
    coada.ultim = NULL;
    coada.prim = coada.ultim = citire();
}

void afisare_numar(Nod* numar)
{
    if(numar->pim >= 0)
        cout<<numar->pr<<" + "<<numar->pim<<"i"<<endl;
    else
        cout<<numar->pr<<" - "<<-numar->pim<<"i"<<endl;

}

void afis(Coada coada)
{
    if(coada.prim)
    {
        Nod *a;
        for(a=coada.prim; a->urm; a=a->urm)
        {
            afisare_numar(a);
        }
        afisare_numar(a);
    }
    else
        cout<<"Lista vida!\n";

}

void adaugare(Coada &coada)
{
    Nod *nou;
    cout<<"adauga\n";
    nou = citire();
    if (coada.prim)
    {
        coada.ultim->urm = nou;
        nou->prec = coada.ultim;
    }
    else
    {
        nou->prec=NULL;
        coada.prim = nou;
    }
    coada.ultim = nou;
}

bool eliminare(Coada &coada)
{
    if(coada.prim)
    {
        Nod *a=coada.prim->urm;
        a->prec = NULL;
        cout<<"sterge\n";
        delete coada.prim;
        coada.prim = a;
        return true;
    }
    else
    {
        cout<<"Lista este vida.\n";
        return false;
    }
}

int main()
{   Coada c1;
    init(c1);
    adaugare(c1);
    adaugare(c1);
    afis(c1);
    eliminare(c1);
    afis(c1);
    return 0;
}
